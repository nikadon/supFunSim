classdef EEGReconstruction < EEGForwardModel
    % Class used to calculate the reconstruction matrices.
    %
    % EEGReconstruction Properties:
    %    SETUP - setup for simulation.
    %
    % EEGReconstruction Methods:
    %    setpreparations - adjusting signals,
    %    setfilters - calculating filters.
    
    properties(GetAccess='public', SetAccess='public')
        % Properties of the class
        RESULTS;
    end

    methods
        function obj = EEGReconstruction()
            % Constructor of EEGReconstruction class
            obj.RESULTS.table_arrC = [];
            obj.RESULTS.table_varN = {};
            obj.RESULTS.table_rowN = {};
        end
        function obj = setfilters(obj, filters)
            % Filter definitions, evaluation and calculation of
            % reconstruction errors.

            obj.MODEL = spatialfilterconstants(obj.SETUP, obj.MODEL);
            % Calculates matrices which are used in the process of reconstruction.
            for filter = filters
                obj.MODEL = spatialfiltering(obj.SETUP, obj.MODEL, filter);
            end
            obj.MODEL = spatialfilteringexecution(obj.SETUP, obj.MODEL);
            obj.MODEL = spatialfilteringerrorevaluation(obj.SETUP, obj.MODEL);
            obj.MODEL = vectorizerrorevaluation(obj.SETUP, obj.MODEL);
            
            if isempty(obj.RESULTS.table_rowN)
                np = 1;
            else
                np = length(obj.RESULTS.table_rowN) + 1;
            end
            obj.RESULTS.table_rowN{np} = obj.MODEL.rec_res.table_rowN;
            obj.RESULTS.table_varN{np} = obj.MODEL.rec_res.table_varN;
            obj.RESULTS.table_arrC(:, :, np) = obj.MODEL.rec_res.table_arrC;
        end
        function obj = printaverageresults(obj)
            % Printing average results of reconstruction for given filters.
        
            obj.RESULTS.Table = array2table(squeeze(mean(obj.RESULTS.table_arrC, 3)), 'VariableNames', table2array(cell2table(obj.RESULTS.table_varN{1})));
            obj.RESULTS.Table.Properties.RowNames = obj.RESULTS.table_rowN{1};
            disp(obj.RESULTS.Table);
        end
        function save(obj)
            % Method which saves all variables stored in the object.
            
            DATE = datestr(now, 'yyyymmdd_HHMMSS');
            save(['reconstruction_', DATE, '.mat'])
        end
    end
end