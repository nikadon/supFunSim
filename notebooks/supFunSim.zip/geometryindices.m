function model = geometryindices(SETUP, MODEL, MATS)
    % Finds indices corresponding to drawn ROIs.

    model = MODEL;
    model.sim_geo_cort.indROIs = [];
    for ii = 1:length(model.sim_geo_cort.lstROIs)
        tmp_roi = model.sim_geo_cort.lstROIs(ii);
        model.sim_geo_cort.indROIs(ii).pntNum00 = MATS.sel_atl.Atlas(MATS.sel_atl.atl).Scouts(tmp_roi).Vertices';
        model.sim_geo_cort.indROIs(ii).triNum00 = find(all(ismember(MATS.sel_atl.tri, model.sim_geo_cort.indROIs(ii).pntNum00), 2));
    end
end