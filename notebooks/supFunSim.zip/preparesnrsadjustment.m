function model = preparesnrsadjustment(SETUP, MODEL)
    % Adjusts SNR ratio for all source signals.
    % Power of the signals of interest is kept constant while noise
    % signals powers are adjusted according to SETUP.S*NR.

    model = MODEL;
    
    model.sim_sig_AdjSNRs.SrcActivPre = model.sim_sig_SrcActiv.sigSNS_pre;
    model.sim_sig_AdjSNRs.SrcActivPst = model.sim_sig_SrcActiv.sigSNS_pst;
    model.sim_sig_AdjSNRs.IntNoisePre = model.sim_sig_IntNoise.sigSNS_pre;
    model.sim_sig_AdjSNRs.IntNoisePst = model.sim_sig_IntNoise.sigSNS_pst;
    model.sim_sig_AdjSNRs.BcgNoisePre = model.sim_sig_BcgNoise.sigSNS_pre;
    model.sim_sig_AdjSNRs.BcgNoisePst = model.sim_sig_BcgNoise.sigSNS_pst;
    model.sim_sig_AdjSNRs.MesNoisePre = model.sim_sig_MesNoise.sigSNS_pre;
    model.sim_sig_AdjSNRs.MesNoisePst = model.sim_sig_MesNoise.sigSNS_pst;
    for kk = 1:SETUP.K00
        model.sim_sig_AdjSNRs.IntNoisePre(:,:,kk) = rawAdjTotSNRdB(model.sim_sig_AdjSNRs.SrcActivPre(:,:,kk), model.sim_sig_AdjSNRs.IntNoisePre(:,:,kk), SETUP.SINR);
        model.sim_sig_AdjSNRs.IntNoisePst(:,:,kk) = rawAdjTotSNRdB(model.sim_sig_AdjSNRs.SrcActivPst(:,:,kk), model.sim_sig_AdjSNRs.IntNoisePst(:,:,kk), SETUP.SINR);
        model.sim_sig_AdjSNRs.BcgNoisePre(:,:,kk) = rawAdjTotSNRdB(model.sim_sig_AdjSNRs.SrcActivPre(:,:,kk), model.sim_sig_AdjSNRs.BcgNoisePre(:,:,kk), SETUP.SBNR);
        model.sim_sig_AdjSNRs.BcgNoisePst(:,:,kk) = rawAdjTotSNRdB(model.sim_sig_AdjSNRs.SrcActivPst(:,:,kk), model.sim_sig_AdjSNRs.BcgNoisePst(:,:,kk), SETUP.SBNR);
        model.sim_sig_AdjSNRs.MesNoisePre(:,:,kk) = rawAdjTotSNRdB(model.sim_sig_AdjSNRs.SrcActivPre(:,:,kk), model.sim_sig_AdjSNRs.MesNoisePre(:,:,kk), SETUP.SMNR);
        model.sim_sig_AdjSNRs.MesNoisePst(:,:,kk) = rawAdjTotSNRdB(model.sim_sig_AdjSNRs.SrcActivPst(:,:,kk), model.sim_sig_AdjSNRs.MesNoisePst(:,:,kk), SETUP.SMNR);
    end
end