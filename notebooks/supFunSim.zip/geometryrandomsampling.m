function model = geometryrandomsampling(SETUP, MODEL, MATS)
    % Draws random ROIs and vertices.

    model = MODEL;
    model.sim_geo_cort.numROIs = size(MATS.sel_atl.Atlas(MATS.sel_atl.atl).Scouts, 2);

    if SETUP.rROI
        disp('CC: using random ROI locations')
        if SETUP.SEED
            rng(SETUP.SEEDS(5));
        end
        model.sim_geo_cort.lstROIs = randsample([1:model.sim_geo_cort.numROIs], size(SETUP.SRCS, 1));
    else
        disp('CC: using predefined ROI locations')
        %model.sim_geo_cort.lstROIs = [31 30 34 29 56 51 84 53 83 58 57];
        model.sim_geo_cort.lstROIs = model.sim_geo_cort.lstROIs(1:size(SETUP.SRCS, 1));
    end

    if SETUP.rPNT
        disp('CC: using random source locations')
    else
        disp('CC: using predefined source locations')
        model.sim_geo_cort.lstROIs(1) = 31;
    end
end