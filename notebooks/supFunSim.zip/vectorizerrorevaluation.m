function model = vectorizerrorevaluation(SETUP, MODEL)
    % Auxiliary function for plotting error evaluations.

    model = MODEL;

    % Vectorize results
    model.rec_sigAmp_ErrEuclid_vec = cellfun(@(fn) model.rec_sigAmp_ErrEuclid.(fn), fieldnames(model.rec_sigAmp_ErrEuclid), 'UniformOutput', false);
    model.rec_sigAmp_ErrEuclid_vec = squeeze(vertcat(model.rec_sigAmp_ErrEuclid_vec{:}));

    model.rec_sigAmp_ErrCorrCf_vec = cellfun(@(fn) model.rec_sigAmp_ErrCorrCf.(fn), fieldnames(model.rec_sigAmp_ErrCorrCf), 'UniformOutput', false);
    model.rec_sigAmp_ErrCorrCf_vec = squeeze(vertcat(model.rec_sigAmp_ErrCorrCf_vec{:}));

    model.rec_funDep_A00_ErrEuclid_vec = cellfun(@(fn) model.rec_funDep_A00_ErrEuclid.(fn), fieldnames(model.rec_funDep_A00_ErrEuclid), 'UniformOutput', false);
    model.rec_funDep_A00_ErrEuclid_vec = squeeze(vertcat(model.rec_funDep_A00_ErrEuclid_vec{:}));

    model.rec_funDep_A00_ErrCorrCf_vec = cellfun(@(fn) model.rec_funDep_A00_ErrCorrCf.(fn), fieldnames(model.rec_funDep_A00_ErrCorrCf), 'UniformOutput', false);
    model.rec_funDep_A00_ErrCorrCf_vec = squeeze(vertcat(model.rec_funDep_A00_ErrCorrCf_vec{:}));

    model.rec_funDep_PDC_ErrEuclid_vec = cellfun(@(fn) model.rec_funDep_PDC_ErrEuclid.(fn), fieldnames(model.rec_funDep_PDC_ErrEuclid), 'UniformOutput', false);
    model.rec_funDep_PDC_ErrEuclid_vec = squeeze(vertcat(model.rec_funDep_PDC_ErrEuclid_vec{:}));

    model.rec_funDep_PDC_ErrCorrCf_vec = cellfun(@(fn) model.rec_funDep_PDC_ErrCorrCf.(fn), fieldnames(model.rec_funDep_PDC_ErrCorrCf), 'UniformOutput', false);
    model.rec_funDep_PDC_ErrCorrCf_vec = squeeze(vertcat(model.rec_funDep_PDC_ErrCorrCf_vec{:}));

    % Combine results in single array
    if     ~isequal(fieldnames(model.rec_sigAmp_ErrEuclid), fieldnames(model.rec_sigAmp_ErrCorrCf))
        error('check fieldnames')
    elseif ~isequal(fieldnames(model.rec_sigAmp_ErrEuclid), fieldnames(model.rec_funDep_A00_ErrEuclid))
        error('check fieldnames')
    elseif ~isequal(fieldnames(model.rec_sigAmp_ErrEuclid), fieldnames(model.rec_funDep_A00_ErrCorrCf))
        error('check fieldnames')
    elseif ~isequal(fieldnames(model.rec_sigAmp_ErrEuclid), fieldnames(model.rec_funDep_PDC_ErrEuclid))
        error('check fieldnames')
    elseif ~isequal(fieldnames(model.rec_sigAmp_ErrEuclid), fieldnames(model.rec_funDep_PDC_ErrCorrCf))
        error('check fieldnames')
    else
        model.rec_res.table_arrC = [ model.rec_sigAmp_ErrEuclid_vec,  model.rec_sigAmp_ErrCorrCf_vec,  model.rec_funDep_A00_ErrEuclid_vec,  model.rec_funDep_A00_ErrCorrCf_vec,  model.rec_funDep_PDC_ErrEuclid_vec,  model.rec_funDep_PDC_ErrCorrCf_vec];
        model.rec_res.table_varN = {'rec_sigAmp_ErrEuclid_vec', 'rec_sigAmp_ErrCorrCf_vec', 'rec_funDep_A00_ErrEuclid_vec', 'rec_funDep_A00_ErrCorrCf_vec', 'rec_funDep_PDC_ErrEuclid_vec', 'rec_funDep_PDC_ErrCorrCf_vec'};
        model.rec_res.table_rowN = fieldnames(model.rec_sigAmp_ErrEuclid);
        model.rec_res.table = array2table(model.rec_res.table_arrC, 'VariableNames', model.rec_res.table_varN, 'RowNames', model.rec_res.table_rowN);
    end

    if SETUP.DEBUG
        model.rec_res.table_arrC = [ model.rec_sigAmp_ErrEuclid_vec,  model.rec_sigAmp_ErrCorrCf_vec ];
        model.rec_res.table_varN = {'rec_sigAmp_ErrEuclid_vec', 'rec_sigAmp_ErrCorrCf_vec'};
        model.rec_res.table_rowN = fieldnames(model.rec_sigAmp_ErrEuclid);
        model.rec_res.table = array2table(model.rec_res.table_arrC, 'VariableNames', model.rec_res.table_varN, 'RowNames', model.rec_res.table_rowN);
    end
end