function model = spatialfilterconstants(SETUP, MODEL)
    % Calculation of covariance matrices used in filter definitions.

    model = MODEL;
    model.N = cov(reshape(permute(model.y_Pre, [1 3 2]), [], size(model.y_Pre, 2), 1));
    % model.N = cov(reshape(permute(model.y_PstNoise, [1 3 2]), [], size(model.y_PstNoise, 2), 1));
    model.R = cov(reshape(permute(model.y_Pst, [1 3 2]), [], size(model.y_Pst, 2), 1));

    model.G = model.H_Src' * pinv(model.N) * model.H_Src;
    model.S = model.H_Src' * pinv(model.R) * model.H_Src;

    model.G_SrcInt = [model.H_Src model.H_Int]' * pinv(model.N) * [model.H_Src model.H_Int];
    model.S_SrcInt = [model.H_Src model.H_Int]' * pinv(model.R) * [model.H_Src model.H_Int];
    model.C_SrcInt = pinv(model.S_SrcInt) - pinv(model.G_SrcInt);

    % Estimated C for both regular and nulling filters
    model.C_NL = model.C_SrcInt(1:size(model.H_Src, 2), 1:size(model.H_Src, 2));
    model.C = pinv(model.S) - pinv(model.G);
end