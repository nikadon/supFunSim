function model = calculate_sMVP_NL_R(MODEL)
    % Definition of sMVP_NL_R filter.

    model = MODEL;
    
    model.K_NL_MSE = pinv(model.P_sMVP_NL_R * model.H_Src_R) * model.P_sMVP_NL_R * (pinv(model.P_sMVP_NL_R * model.H_Src_R))' - 2*model.C_NL;

    %K_NL_R = pinv(model.P_sMVP_NL_R * model.H_Src_R) * model.P_sMVP_NL_R * (pinv(model.P_sMVP_NL_R * model.H_Src_R))';
    model.K_NL_R = model.K_NL_MSE + 2*model.C_NL;
    [model.U_K_NL_R, model.W_K_NL_R] = eig(model.K_NL_R);

    [~, model.p_K_NL_R] = sort(diag(model.W_K_NL_R));
    model.U_K_NL_R = model.U_K_NL_R(:, model.p_K_NL_R);
    model.sMVP_NL_R_ranks = zeros(1, size(model.H_Src, 2));

    for jj = 1:size(model.H_Src, 2)
        % cost function
        model.sMVP_NL_R_ranks(jj) = trace(model.U_K_NL_R(:, 1:jj) * model.U_K_NL_R(:, 1:jj)' * model.K_NL_MSE);
    end

    [~, model.sMVP_NL_R_rank_opt] = min(model.sMVP_NL_R_ranks);
    % _opt stands for optimal
    model.P_sMVP_NL_R_opt = model.U_K_NL_R(:, 1:model.sMVP_NL_R_rank_opt) * model.U_K_NL_R(:, 1:model.sMVP_NL_R_rank_opt)';

    model.rec_opt.ranks.sMVP_NL_R = model.sMVP_NL_R_rank_opt;

    model.rec_flt.sMVP_NL_R = model.P_sMVP_NL_R_opt * pinv(model.P_sMVP_NL_R * model.H_Src_R) * model.P_sMVP_NL_R * pinv(sqrtm(model.R));
end