function model = calculate_LCMV_R(MODEL)
    % Definition of LMCV(R) filter

    model = MODEL;
    
    model.rec_flt.LCMV_R = pinv(model.S) * model.H_Src' * pinv(model.R);
end