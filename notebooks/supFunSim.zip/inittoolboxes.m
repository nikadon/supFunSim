function MATS = inittoolboxes()
    % Auxiliary toolboxes added to path.
    % Required *.mat files containing meshes are loaded here.

    if exist('~/toolboxes/', 'dir') == 7
        TMP_TOOLB_PATH = '~/toolboxes/';
    else
        warningMessage = sprintf('CYBERCRAFT:: Warning:: toolboxes directory was not found (use ''~/toolboxes/'')');
    end;
    if exist('TMP_TOOLB_PATH', 'var')
        disp(['CYBERCRAFT:: looking for toolboxes in: ', TMP_TOOLB_PATH])
    end;
     addpath([TMP_TOOLB_PATH, '/arfit']);
     addpath([TMP_TOOLB_PATH, '/mvarica']);
     
         % Loading meshes
    
    load('./mat/sel_msh.mat');                     % head compartments geometry (cortex)
    load('./mat/sel_geo_deep_thalami.mat');        % mesh containing candidates for lacation of deep sources (based on thalami)
    load('./mat/sel_geo_deep_icosahedron642.mat'); % mesh containing candidates for lacation of deep sources (based on icosahedron642)
    load('./mat/sel_atl.mat');                     % cortex geometry with (anatomical) ROI parcellation
    load('./mat/sel_vol.mat');                     % volume conduction model (head-model)
    load('./mat/sel_ele.mat');                     % geometry of electrode positions
    load('./mat/sel_src.mat');                     % all cx leadfields

    MATS = [];
    MATS.sel_msh = sel_msh;
    MATS.sel_geo_deep_thalami = sel_geo_deep_thalami;
    MATS.sel_geo_deep_icosahedron642 = sel_geo_deep_icosahedron642;
    MATS.sel_atl = sel_atl; % Atlas from Brainstorm, about 15000 vertices
    MATS.sel_vol = sel_vol; % Volumne conduction model
    MATS.sel_ele = sel_ele; % Electrodes in FieldTrip model
    MATS.sel_src = sel_src; % Sources leadfields
end