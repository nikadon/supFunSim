function model = generatetimeseriesbackgroundnoise(SETUP, MODEL)
    % Generates time series background noise.

    model = MODEL;
    model.sim_sig_BcgNoise = cccSim___makeSimSig(SETUP, 3, 'MVAR based signal for background (biological) noise activity sources');
end