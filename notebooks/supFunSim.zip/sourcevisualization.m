function sourcevisualization(MODEL)

    % mesh for deep sources ROI
    deepsourcesasgraph(MODEL.sim_geo_deep);

    % sources
    sourcequivers(MODEL.sim_geo);
    
    % legend('SrcActiv\_orig', 'SrcActiv\_pert', 'IntNoise\_orig', 'IntNoise\_pert', 'BcgNoise\_orig', 'BcgNoise\_pert')
end