classdef EEGParameters
    % A class which is used for generating parameters.
    %
    % EEGParameters Properties:
    %
    % EEGParameters Methods:
    %    generate - returns a list of setups for simulations.

    properties(GetAccess='public', SetAccess='public')
    end
    methods
        function obj = EEGParameters()
        end
        function SETUPS = generate(obj)
            % Generates a list of simulation setups.
            % Sample simulation parameter settings.

            SETUP = generatedummysetup();
            SETUPS = [];
            % The following example generates set of setups with
            % SBNR parameter varying across given range.
            
            for i = 1:length(SETUP.SINR_RNG)
                SETUP.SINR = SETUP.SINR_RNG(i)
                for j = 1:length(SETUP.SBNR_RNG)
                    SETUP.SBNR = SETUP.SBNR_RNG(j)
                    for k = 1:length(SETUP.SMNR_RNG)
                        SETUP.SMNR = SETUP.SMNR_RNG(k)
                        SETUPS = [SETUPS; SETUP];
                    end
                end
            end
        end
    end
end