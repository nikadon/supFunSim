function model = calculate_P_sMVP_R_opt(MODEL)
    % Definition of P_sMVP(R) projection.

    model = MODEL;
    
    % note: pinv(model.H_Src_R)*pinv(model.H_Src_R)' = pinv(S)
    model.K_MSE = pinv(model.S) - 2*model.C;

    model.K_R = model.K_MSE + 2*model.C;
    [model.U_K_R, model.W_K_R] = eig(model.K_R);
    [~, model.p_K_R] = sort(diag(model.W_K_R));
    model.U_K_R = model.U_K_R(:, model.p_K_R);
    model.sMVP_R_ranks = zeros(1, size(model.H_Src, 2));

    for jj = 1:size(model.H_Src, 2)
        model.sMVP_R_ranks(jj) = trace(model.U_K_R(:, 1:jj) * model.U_K_R(:, 1:jj)' * model.K_MSE);
    end

    [~, model.sMVP_R_rank_opt] = min(model.sMVP_R_ranks);
    % _opt stands for optimal
    model.P_sMVP_R_opt = model.U_K_R(:, 1:model.sMVP_R_rank_opt) * model.U_K_R(:, 1:model.sMVP_R_rank_opt)';
end