function model = geometryleadfieldscomputation(SETUP, MODEL, MATS)
    % Generates lead-fields using FieldTrip.

    model = MODEL;
    
    % WARNING:: suppress warning about MATLAB version and CFG tracking
    
    if SETUP.DEBUG
       TMP_S = warning('off', 'all');
    end

    tmp_cfg            = [];
    tmp_cfg.grid.unit  = 'mm';
    tmp_cfg.reducerank = 'no';
    tmp_cfg.normalize  = 'no';
    tmp_cfg.elec       = MATS.sel_ele;
    tmp_cfg.vol        = MATS.sel_vol;

    ii = 1;
    tmp_cfg.grid.pos          = model.sim_geo.pos_orig{ii};
    tmp_cfg.grid.mom          = transpose(model.sim_geo.ori_orig{ii});
    model.sim_lfg_SrcActiv_orig.lfg = ft_prepare_leadfield(tmp_cfg);
    model.sim_lfg_SrcActiv_orig.LFG = cat(2, model.sim_lfg_SrcActiv_orig.lfg.leadfield{:});

    tmp_cfg.grid.pos          = model.sim_geo.pos_pert{ii};
    tmp_cfg.grid.mom          = transpose(model.sim_geo.ori_pert{ii});
    model.sim_lfg_SrcActiv_pert.lfg = ft_prepare_leadfield(tmp_cfg);
    model.sim_lfg_SrcActiv_pert.LFG = cat(2, model.sim_lfg_SrcActiv_pert.lfg.leadfield{:});

    ii = 2;
    tmp_cfg.grid.pos          = model.sim_geo.pos_orig{ii};
    tmp_cfg.grid.mom          = transpose(model.sim_geo.pos_orig{ii});
    model.sim_lfg_IntNoise_orig.lfg = ft_prepare_leadfield(tmp_cfg);
    model.sim_lfg_IntNoise_orig.LFG = cat(2, model.sim_lfg_IntNoise_orig.lfg.leadfield{:});

    tmp_cfg.grid.pos          = model.sim_geo.pos_pert{ii};
    tmp_cfg.grid.mom          = transpose(model.sim_geo.pos_pert{ii});
    model.sim_lfg_IntNoise_pert.lfg = ft_prepare_leadfield(tmp_cfg);
    model.sim_lfg_IntNoise_pert.LFG = cat(2, model.sim_lfg_IntNoise_pert.lfg.leadfield{:});

    ii = 3;
    tmp_cfg.grid.pos          = model.sim_geo.pos_orig{ii};
    tmp_cfg.grid.mom          = transpose(model.sim_geo.pos_orig{ii});
    model.sim_lfg_BcgNoise_orig.lfg = ft_prepare_leadfield(tmp_cfg);
    model.sim_lfg_BcgNoise_orig.LFG = cat(2, model.sim_lfg_BcgNoise_orig.lfg.leadfield{:});

    tmp_cfg.grid.pos          = model.sim_geo.pos_pert{ii};
    tmp_cfg.grid.mom          = transpose(model.sim_geo.pos_pert{ii});
    model.sim_lfg_BcgNoise_pert.lfg = ft_prepare_leadfield(tmp_cfg);
    model.sim_lfg_BcgNoise_pert.LFG = cat(2, model.sim_lfg_BcgNoise_pert.lfg.leadfield{:});
end