classdef EEGPlotting
    properties(GetAccess='public', SetAccess='public')
        SETUP;
        MODEL;
        MATS;
    end
    methods
        function obj = EEGPlotting(simulation)
            % Constructor of EEGPlotting class

            initialize()
            obj.SETUP = simulation.SETUP;
            obj.MODEL = simulation.MODEL;
            obj.MATS = simulation.MATS;
        end
        function plotMVARmodelcoefficientmatrixmask(obj)
            % Method for plotting MVAR mask matrix.

            MVARmodelcoefficientmatrixmask(obj.SETUP, obj.MODEL);
        end
        function plotPDCgraph(obj)
            % Method for plotting PDC profiles across sources of interest and interfering sources.

            PDCgraph(obj.SETUP, obj.MODEL);
        end
        function plotMVARmodelcoefficientmatrixgraph(obj)
            % Method for plotting composite MVAR model matrix for sources of interest, interfering and background sources.

            MVARmodelcoefficientmatrixgraph(obj.SETUP, obj.MODEL);
        end
        function ploterrortable(obj)
            % Method for plotting result of reconstruction.
            
            errortable(obj.MODEL);
        end
        function plotdeepsourcesasicosahedron642(obj)
            % Auxiliary plotting of deep sources.

            deepsourcesasicosahedron642(obj.MATS);
        end
        function plotdeepsourcesasthalami(obj)
            % Auxiliary plotting of both thalami.

            deepsourcesasthalami(obj.MATS);
        end
        function plotcortexmesh(obj)
            % Auxiliary plotting of cortex mesh.

            cortexmesh(obj.MATS);
        end
        function plotbrainoutermesh(obj)
            % Auxiliary plotting of brain mesh.

            brainoutermesh(obj.MATS);
        end
        function plotskulloutermesh(obj)
            % Auxiliary plotting of skull outer mesh.

            skulloutermesh(obj.MATS);
        end
        function plotscalpoutermesh(obj)
            % Auxliary plotting of scalp outer mesh.
            
            scalpoutermesh(obj.MATS);
        end
        function plotelectrodepositioning(obj)
            % Auxiliary plotting of electrode positions.

            electrodepositioning(obj.MATS);
        end
        function plotelectrodelabels(obj)
            % Auxiliary plotting of electrode positions.

            electrodelabels(obj.MATS);
        end
        function plotROIvisualization(obj)
            % Auxiliary plotting of ROIs based on generated meshes.

            ROIvisualization(obj.MODEL, obj.MATS);
        end
        function plotsourcevisualization(obj)
            % Auxiliary plotting of source vizualization.

            sourcevisualization(obj.MODEL);
        end
        function plotall(obj)
            close all;
            plotMVARmodelcoefficientmatrixmask(obj);
            plotPDCgraph(obj);
            plotMVARmodelcoefficientmatrixgraph(obj);
            ploterrortable(obj);
            figure('Color', [1, 1, 1]);
            plotdeepsourcesasicosahedron642(obj);
            plotdeepsourcesasthalami(obj);
            plotcortexmesh(obj);
            plotbrainoutermesh(obj);
            plotskulloutermesh(obj);
            plotscalpoutermesh(obj);
            plotelectrodepositioning(obj);
            plotelectrodelabels(obj);
            plotROIvisualization(obj);
            plotsourcevisualization(obj);
        end
    end
end