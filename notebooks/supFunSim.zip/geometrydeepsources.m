function model = geometrydeepsources(SETUP, MODEL, MATS)
   % Finds coordinates corresponding to drawn deep sources (thalami).

    model = MODEL;
    if SETUP.thalamus == "ico"
        model.sim_geo_deep = MATS.sel_geo_deep_icosahedron642;
    else
        model.sim_geo_deep = MATS.sel_geo_deep_thalami;
    end

    if SETUP.SEED
        rng(SETUP.SEEDS(5));
    end
    model.sim_geo_deep.bulkSRC = randsample(1:size(model.sim_geo_deep.pnt, 1), sum(SETUP.DEEP))';

    [model.sim_geo_deep.mergeSRC{1}, model.sim_geo_deep.mergeSRC{2}, model.sim_geo_deep.mergeSRC{3}] = deal([]);

    model.sim_geo_deep.mergeSRC{1, 1} = model.sim_geo_deep.bulkSRC(1:SETUP.DEEP(1));
    model.sim_geo_deep.mergeSRC{1, 2} = model.sim_geo_deep.bulkSRC(1 + SETUP.DEEP(1):SETUP.DEEP(1) + SETUP.DEEP(2));
    model.sim_geo_deep.mergeSRC{1, 3} = model.sim_geo_deep.bulkSRC(1 + SETUP.DEEP(1) + SETUP.DEEP(2):SETUP.DEEP(1) + SETUP.DEEP(2) + SETUP.DEEP(3));

    model.sim_geo_deep.pos_orig = {};
    model.sim_geo_deep.ori_orig = {};
    model.sim_geo_deep.pos_pert = {};
    model.sim_geo_deep.ori_pert = {};

    for ii = 1:3
        model.sim_geo_deep.pos_orig{ii} = model.sim_geo_deep.pnt(model.sim_geo_deep.mergeSRC{ii}, :);
        model.sim_geo_deep.ori_orig{ii} = model.sim_geo_deep.vn1(model.sim_geo_deep.mergeSRC{ii}, :);
        model.sim_geo_deep.pos_pert{ii} = model.sim_geo_deep.pos_orig{ii};
        model.sim_geo_deep.ori_pert{ii} = model.sim_geo_deep.ori_orig{ii};
    end

    model.sim_geo = model.sim_geo_cort;
    for ii = 1:3
        model.sim_geo.pos_orig{ii} = [model.sim_geo.pos_orig{ii}; model.sim_geo_deep.pos_orig{ii}];
        model.sim_geo.ori_orig{ii} = [model.sim_geo.ori_orig{ii}; model.sim_geo_deep.ori_orig{ii}];
        model.sim_geo.pos_pert{ii} = [model.sim_geo.pos_pert{ii}; model.sim_geo_deep.pos_pert{ii}];
        model.sim_geo.ori_pert{ii} = [model.sim_geo.ori_pert{ii}; model.sim_geo_deep.ori_pert{ii}];
    end;
end