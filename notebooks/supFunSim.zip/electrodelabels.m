function electrodelabels(MATS)
    % Plot electrode labels

    text(  MATS.sel_ele.elecpos(:, 1) * 1.2, ...
           MATS.sel_ele.elecpos(:, 2) * 1.2, ...
           MATS.sel_ele.elecpos(:, 3) * 1.2, ...
           MATS.sel_ele.label, 'Color', [0.5 0.3 0.5], 'FontSize', 10);
    hold on
    ccrender([-160, 160], 'finish', 'matte')    
end