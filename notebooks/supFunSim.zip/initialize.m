function initialize()
    % Initialize toolboxes.

    TMP_TOOLB_PATH = '~/toolboxes/';
    addpath([TMP_TOOLB_PATH, '/mvarica']);
    addpath([TMP_TOOLB_PATH, 'fieldtrip/']);
    if exist([TMP_TOOLB_PATH, 'fieldtrip/privatePublic/', filesep])
        addpath([TMP_TOOLB_PATH, 'fieldtrip/privatePublic/', filesep]);
    else
        copyfile([TMP_TOOLB_PATH, 'fieldtrip/private/', filesep], [TMP_TOOLB_PATH, 'fieldtrip/privatePublic/', filesep]);
        addpath([TMP_TOOLB_PATH, 'fieldtrip/privatePublic/', filesep]);
    end;
    if exist([TMP_TOOLB_PATH, 'fieldtrip/forward/privatePublic/', filesep])
        addpath([TMP_TOOLB_PATH, 'fieldtrip/forward/privatePublic/', filesep]);
    else
        copyfile([TMP_TOOLB_PATH, 'fieldtrip/forward/private/', filesep], [TMP_TOOLB_PATH, 'fieldtrip/forward/privatePublic/', filesep]);
        addpath([TMP_TOOLB_PATH, 'fieldtrip/forward/privatePublic/', filesep]);
    end;
    addpath([TMP_TOOLB_PATH, 'fieldtrip/utilities']);
    if exist([TMP_TOOLB_PATH, 'fieldtrip/utilities/privatePublic/', filesep])
        addpath([TMP_TOOLB_PATH, 'fieldtrip/utilities/privatePublic/', filesep]);
    else
        copyfile([TMP_TOOLB_PATH, 'fieldtrip/utilities/private/', filesep], [TMP_TOOLB_PATH, 'fieldtrip/utilities/privatePublic/', filesep]);
        addpath([TMP_TOOLB_PATH, 'fieldtrip/utilities/privatePublic/', filesep]);
    end;
    % Initialize FieldTrip
    ft_defaults;
end