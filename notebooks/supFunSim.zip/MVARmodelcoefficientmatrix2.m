function MVARmodelcoefficientmatrix2(SETUP, MODEL)

    figure(105);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    subplot(2, 1, 1);
    cccSim___rawDispA00(MODEL.sim_sig_SrcActiv.A00);
    title('A00');
    subplot(2, 1, 2);
    cccSim___rawDispA00(MODEL.sim_sig_SrcActiv.A01);
    title('A01');
    set(gcf, 'color', 'w');
end