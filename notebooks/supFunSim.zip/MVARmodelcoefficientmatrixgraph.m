function MVARmodelcoefficientmatrixgraph(SETUP, MODEL)

    figure(55);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    subplot(6, 1, 1);
    rawDispA00(MODEL.sim_sig_SrcActiv.A00);
    title('sim\_sig\_SrcActiv.A00')
    subplot(6, 1, 2);
    rawDispA00(MODEL.sim_sig_SrcActiv.A01);
    title('sim\_sig\_SrcActiv.A01')
    subplot(6, 1, 3);
    rawDispA00(MODEL.sim_sig_IntNoise.A00);
    title('sim\_sig\_IntNoise.A00')
    subplot(6, 1, 4);
    rawDispA00(MODEL.sim_sig_IntNoise.A01);
    title('sim\_sig\_IntNoise.A01')
    subplot(6, 1, 5);
    rawDispA00(MODEL.sim_sig_BcgNoise.A00);
    title('sim\_sig\_BcgNoise.A00')
    subplot(6, 1, 6);
    rawDispA00(MODEL.sim_sig_BcgNoise.A01);
    title('sim\_sig\_BcgNoise.A01')
end