function MVARmodelcoefficientmatrix6(SETUP, MODEL)

    close all
    figure(55);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    subplot(6, 1, 1);
    cccSim___rawDispA00(MODEL.sim_sig_SrcActiv.A00);
    title('sim\_sig\_SrcActiv.A00')
    subplot(6, 1, 2);
    cccSim___rawDispA00(MODEL.sim_sig_SrcActiv.A01);
    title('sim\_sig\_SrcActiv.A01')
    subplot(6, 1, 3);
    cccSim___rawDispA00(MODEL.sim_sig_IntNoise.A00);
    title('sim\_sig\_IntNoise.A00')
    subplot(6, 1, 4);
    cccSim___rawDispA00(MODEL.sim_sig_IntNoise.A01);
    title('sim\_sig\_IntNoise.A01')
    subplot(6, 1, 5);
    cccSim___rawDispA00(MODEL.sim_sig_BcgNoise.A00);
    title('sim\_sig\_BcgNoise.A00')
    subplot(6, 1, 6);
    cccSim___rawDispA00(MODEL.sim_sig_BcgNoise.A01);
    title('sim\_sig\_BcgNoise.A01')
end