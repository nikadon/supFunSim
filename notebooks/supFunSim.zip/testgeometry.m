function temp = testgeometry()
    % Importing code generated from Org-mode files.

    load("tangled.mat");

    run('./tangled/tg_s02_Geometry___01_RandSamp.m');
    run('./tangled/tg_s02_Geometry___02_Indices.m');
    run('./tangled/tg_s02_Geometry___03_Coordinates.m');
    run('./tangled/tg_s02_Geometry___04_DeepSrc.m');
    run('./tangled/tg_s02_Geometry___05_Perturbation.m');
    run('./tangled/tg_s02_Geometry___06_lfg.m');
    run('./tangled/tg_s03_Forward_modeling.m');

    temp.sim_sig_SrcActiv = sim_sig_SrcActiv;
    temp.sim_sig_IntNoise = sim_sig_IntNoise;
    temp.sim_sig_BcgNoise = sim_sig_BcgNoise;
    temp.sim_sig_MesNoise = sim_sig_MesNoise;

    temp.sim_geo_cort           = sim_geo_cort;
    temp.sim_geo_deep           = sim_geo_deep;
    temp.sim_geo                = sim_geo;
    temp.sim_lfg_SrcActiv_orig  = sim_lfg_SrcActiv_orig;
    temp.sim_lfg_SrcActiv_pert  = sim_lfg_SrcActiv_pert;
    temp.sim_lfg_IntNoise_orig  = sim_lfg_IntNoise_orig;
    temp.sim_lfg_IntNoise_pert  = sim_lfg_IntNoise_pert;
    temp.sim_lfg_BcgNoise_orig  = sim_lfg_BcgNoise_orig;
    temp.sim_lfg_BcgNoise_pert  = sim_lfg_BcgNoise_pert;
    
    save("tangled.mat");
end