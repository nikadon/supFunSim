function model = generatetimeseriesmeasurementnoise(SETUP, MODEL, MATS)
    % Generates time series measurement noise.

    model = MODEL;
    model.sim_sig_MesNoise.inf = 'RANDN based signal for measurement noise';
    if SETUP.SEED
        rng(SETUP.SEEDS(2));
    end
    model.sim_sig_MesNoise.sigSNS_pre = randn([SETUP.n00, size(MATS.sel_ele.chanpos, 1), SETUP.K00]);
    if SETUP.SEED
        rng(SETUP.SEEDS(2));
    end
    model.sim_sig_MesNoise.sigSNS_pst = randn([SETUP.n00, size(MATS.sel_ele.chanpos, 1), SETUP.K00]);
end