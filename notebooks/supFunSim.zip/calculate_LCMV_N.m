function model = calculate_LCMV_N(MODEL)
    % Definition of LMCV(N) filter

    model = MODEL;
    
    model.rec_flt.LCMV_N = pinv(model.G) * model.H_Src' * pinv(model.N);
end