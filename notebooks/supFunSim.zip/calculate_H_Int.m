function model = calculate_H_Int(MODEL)
    % Auxiliary matrices used in filter definitions.

    model = MODEL;
    
    model.H_Int_R = pinv(sqrtm(model.R)) * model.H_Int;
    model.H_Int_N = pinv(sqrtm(model.N)) * model.H_Int;
end