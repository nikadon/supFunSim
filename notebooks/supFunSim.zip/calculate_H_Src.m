function model = calculate_H_Src(MODEL)
    % Auxiliary matrices used in filter definitions.

    model = MODEL;
    
    model.H_Src_R = pinv(sqrtm(model.R)) * model.H_Src;
    model.H_Src_N = pinv(sqrtm(model.N)) * model.H_Src;
end