classdef EEGSignalGenerator
    % A class which can be used for generating signals from activity sources.
    %
    % EEGSignalGenerator Properties:
    %    SETUP - setup for simulation,
    %    MODEL - model variables.
    %
    % EEGSignalGenerator Methods:
    %    init - initilize neccesary toolboxes,
    %    setparameters - setting up parameters for simulation,
    %    setsignals - creating signals.
    
    properties(GetAccess='public', SetAccess='public')
        % Properties of the class
        
        SETUP;
        MODEL;
        MATS;
    end

    methods
        function obj = EEGSignalGenerator()
            % Constructor of the EEGSignalGenerator class

            obj.SETUP = [];
            obj.MODEL = [];
        end
        function SETUP = get.SETUP(obj)
            % Getter for variable SETUP

            SETUP = obj.SETUP;
        end
        function obj = set.SETUP(obj, NEWSETUP)
            % Setter for variable SETUP

            obj.SETUP = NEWSETUP;
        end
        function r = init(obj)
            % Initialize toolboxes.

            MATS = inittoolboxes();
            r = obj;
            r.MATS = MATS;
        end
        function obj = setparameters(obj, SETUP)
            % Sets parameters for simulation.

            obj.SETUP = SETUP;
        end
        function obj = setsignals(obj)
            % Create signals. Feel free to change.
            
            disp('CYBERCRAFT:: Generation of timeseries for bioelectrical activity of interest')
            obj.MODEL = generatetimeseriessourceactivity(obj.SETUP, obj.MODEL);

            disp('CYBERCRAFT:: Generation of timeseries for bioelectrical interference noise')
            obj.MODEL = generatetimeseriesinterferencenoise(obj.SETUP, obj.MODEL);

            disp('CYBERCRAFT:: Generation of timeseries for bioelectrical background noise')
            obj.MODEL = generatetimeseriesbackgroundnoise(obj.SETUP, obj.MODEL);

            disp('CYBERCRAFT:: Measurement noise generation')
            obj.MODEL = generatetimeseriesmeasurementnoise(obj.SETUP, obj.MODEL, obj.MATS);
        end
    end
end