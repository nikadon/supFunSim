function MVARmodelcoefficientmatrix4(SETUP, MODEL)

    close all
    figure(55);
    clf;
    set(gcf,'Position',[0 0 900 600])
    %set(gcf, 'Position', SETUP.DISP);
    subplot(4, 1, 1);
    cccSim___rawDispA00(MODEL.sim_sig_SrcActiv.A00);
    title('sim\_sig00.A00');
    subplot(4, 1, 2);
    cccSim___rawDispA00(MODEL.sim_sig_SrcActiv.A01);
    title('sim\_sig00.A01');
    subplot(4, 1, 3);
    cccSim___rawDispA00(MODEL.sim_sig_IntNoise.A00);
    title('sim\_sig30.A00');
    subplot(4, 1, 4);
    cccSim___rawDispA00(MODEL.sim_sig_IntNoise.A01);
    title('sim\_sig30.A01');
    set(gcf, 'color', 'w');
end