function MVARmodelcoefficientmatrix5(SETUP, MODEL)

    close all
    figure(105);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    subplot(2, 1, 1);
    cccSim___rawDispA00(MODEL.sim_sig_BcgNoise.A00);
    title('A00');
    subplot(2, 1, 2);
    cccSim___rawDispA00(MODEL.sim_sig_BcgNoise.A01);
    title('A01');
    set(gcf, 'color', 'w');
    figure(100);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    cccSim___rawPlotA00(MODEL.sim_sig_SrcActiv.A01);
    set(gcf, 'color', 'w');
    figure(130);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    cccSim___rawPlotA00(MODEL.sim_sig_IntNoise.A01);
    set(gcf, 'color', 'w');
    figure(140);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    cccSim___rawPlotA00(MODEL.sim_sig_BcgNoise.A01);
    set(gcf, 'color', 'w');
end