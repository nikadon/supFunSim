function SETUP = setinitialvalues(SETUP)
    % Simulations main setup

    SETUP.rROI   = logical(0);     % random (1) or predefined (0) ROIs
    SETUP.rPNT   = logical(0);     % random (1) or predefined (0) candidate points for source locations 
    % number of sources as in SETUP.SRCS(1,1) will be fixed and in close locations
    SETUP.SRCS   = []; % Cortical sources (avoid placing more than 10 sources in single ROI)
    SETUP.SRCS   = [ SETUP.SRCS;  8  0  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  2  0  0 ];
    SETUP.SRCS   = [ SETUP.SRCS;  2  1  0 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  4  0 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  4  0 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  4  0 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  4  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  0  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  0  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  0  3 ];
    SETUP.DEEP   = [              2  1  6 ]; % deep sources
    SETUP.ERPs   = 5;      % Add ERPs (timelocked activity)
    %SETUP.rROI   = 0;     % random (1) or predefined (0) ROIs
    %SETUP.ELEC   = size(MATS.sel_ele.elecpos, 1); % number of electrodes
    SETUP.n00    = 500;    % number of time samples per trial
    SETUP.K00    = 1;      % number of independent realizations of signal and noise based on generated MVAR model
    % note: covariance matrix R of observed signal and noise covariance
    % matrix N are estimated from samples originating from all realizations
    % of signal and noise 
    SETUP.P00    = 6;      % order of the MVAR model used to generate time-courses for signal of interest
    SETUP.FRAC   = 0.20;   % proportion of ones to zeros in off-diagonal elements of the MVAR coefficients masking array
    SETUP.STAB   = 0.99;   % MVAR stability limit for MVAR eigenvalues (less than 1.0 results in more stable model producing more stationary signals)
    SETUP.RNG    = [0, 2.8]; % range for pseudo-random sampling of eigenvalues for MVAR coefficients range
    SETUP.ITER   = 5e5;    % iterations limit for MVAR pseudo-random sampling and stability verification
    SETUP.PDC_RES = [0:0.01:0.5]; % resolution vector for normalized PDC estimation
    SETUP.TELL   = 1;      % provide additional comments during code execution ("tell me more")
    SETUP.PLOT   = 1;      % plot figures during the intermediate stages
    SETUP.SCRN   = get(0, 'MonitorPositions'); % get screens positions
    SETUP.DISP   = SETUP.SCRN(end, :);        % force figures to be displayed on (3dr) screenscreen
    %SETUP.SEED   = rng(round(1e3 * randn()^2 * sum(clock)));
    SETUP.SEED   = 1; % If you want to set SEED
    SETUP.SEEDS = [0, 0, 0, 0, 0]; % Interference Noise Seed, Measurment Noise Seed, arsim, datasample, geometry
    SETUP.RANK_EIG = sum(SETUP.SRCS(:, 1)); % rank of EIG-LCMV filter: set to number of active sources
    SETUP.fltREMOVE = 1; % to keep (0) or remove (1) selected filters
    SETUP.SHOWori = 1; % to show (1) or do not show (0) Original and Dummy signals on Figures
    SETUP.IntLfgRANK = round(0.3 * sum(SETUP.SRCS(:, 2))); % rank of patch-constrained reduced-rank leadfield
    SETUP.supSwitch = 'rec'; % 'rec': run reconstruction of sources activity, 'loc': find active sources
    SETUP.thalamus = 'ico';
    SETUP.DEBUG = 0;
    SETUP.PATH = './';
    
    % Get some details for simulation output filename (*.mat file)
    SETUP.DATE = datestr(now, 'yyyymmdd_HHMMSS');
    SETUP.NAME = tempname;
    [~, SETUP.NAME] = fileparts(SETUP.NAME); % simulation unique name
end