function model = geometryperturbation(SETUP, MODEL, MATS)
    % Perturbate original vertices coordinates by shifting randomly
    % within a cube o a given side length centred at the original
    % source location as well as orientation of each source within
    % prescribed azimuth and elevation, both centred at the original
    % source orientation.

    providepathstonecessarytoolboxes();
    model = MODEL;
    
    if SETUP.SEED
        rng(SETUP.SEEDS(5));
    end
    for ii = 1:3  
        model.sim_geo.ori_pert{ii} = normr(rawSphToCart(rawCartToSph(model.sim_geo.ori_orig{ii}) + [SETUP.CONE * 0.5 * (2*rand(size(model.sim_geo.ori_pert{ii}, 1), 2) - 1), zeros(size(model.sim_geo.ori_pert{ii}, 1), 1)]));
    end
    tmp_count = 0;
    for ii = 1:3
        for jj = 1:size(model.sim_geo.pos_pert{ii}, 1)
            tmp_srcInside = false;
            while ~tmp_srcInside
                tmp_count = tmp_count + 1;
                model.sim_geo.pos_pert{ii}(jj, :) = model.sim_geo.pos_orig{ii}(jj, :) + SETUP.CUBE * 0.5 * (2*rand([1, 3]) - 1);
                tmp_srcInside = bounding_mesh(model.sim_geo.pos_pert{ii}(jj, :), MATS.sel_msh.bnd(1).pnt, MATS.sel_msh.bnd(1).tri);
            end
        end
    end
    if SETUP.TELL
        disp(['CYBERCRAFT:: Perturbation took ', tmp_count, ' iterations'])
    end
end