function [ ] = ccdisp(str)
    % CCDISP display as CYBERCRAFT
    %
    % Use
    %
    %   ccdisp( str )
    %
    
    % add here "try + catch" OR "ifexists"

    disp(['CYBERCRAFT: ', str]);

return