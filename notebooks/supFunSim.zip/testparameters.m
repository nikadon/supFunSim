function SETUP = testparameters(setup)
    % Setup created for unit test.

    SETUP = setup;
    
    SETUP.SEED   = 1;
    SETUP.SEEDS = [0, 0, 0, 0, 0];
    SETUP.ERPs   = 0;

    SETUP.rPNT   = logical(0);    % random (1) or predefined (0) candidate points for source locations: 
    SETUP.SRCS   = []; % Cortical sources (avoid placing more than 10 sources in single ROI)
    SETUP.SRCS   = [ SETUP.SRCS;  3  0  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  3  0  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  3  1  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  4  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  4  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  4  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  4  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  0  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  0  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  0  3 ];
    SETUP.DEEP   = [              0  1  6 ]; % deep sources
  
    SETUP.SHOWori = 0;
    SETUP.n00     = 500;
    SETUP.SBNR_RNG = [0];
    
    SETUP.H_Src_pert     = 0;
    SETUP.H_Int_pert     = 0;
    
    SETUP.SINR           = 0;
    SETUP.SBNR           = 0;
    SETUP.SMNR           = 0;
    
    SETUP.IntPst         = 1;
    
    SETUP.ELEC = 129;
    SETUP.RANK_EIG = sum(SETUP.SRCS(:, 1));
    
    SETUP.PATH = "/home/krykaczewski/supFunSim";
    
    SETUP.supSwitch == 'rec';
end