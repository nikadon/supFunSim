function model = calculate_P_sMVP_N_opt(MODEL)
    % Definition of P_sMVP(N) projection.

    model = MODEL;
    
    model.K_MSE_N = pinv(model.G) - model.C;

    model.K_N = model.K_MSE_N + model.C;
    [model.U_K_N, model.W_K_N] = eig(model.K_N);
    [~, model.p_K_N] = sort(diag(model.W_K_N));
    model.U_K_N = model.U_K_N(:, model.p_K_N);
    model.sMVP_N_ranks = zeros(1, size(model.H_Src, 2));

    for jj = 1:size(model.H_Src, 2)
        model.sMVP_N_ranks(jj) = trace(model.U_K_N(:, 1:jj) * model.U_K_N(:, 1:jj)' * model.K_MSE_N);
    end

    [~, model.sMVP_N_rank_opt] = min(model.sMVP_N_ranks);
    % _opt stands for optimal
    model.P_sMVP_N_opt = model.U_K_N(:, 1:model.sMVP_N_rank_opt) * model.U_K_N(:, 1:model.sMVP_N_rank_opt)';
end