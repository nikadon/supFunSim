function temp = testtimeseries()
    % Importing code generated from Org-mode files.

    load("tangled.mat");
    SETUP.DEBUG = 0; % Added for simplicity

    run('./tangled/tg_s01_Timeseries___01_SrcActiv.m');
    run('./tangled/tg_s01_Timeseries___02_IntNoise.m');
    run('./tangled/tg_s01_Timeseries___03_BcgNoise.m');
    run('./tangled/tg_s01_Timeseries___04_MesNoise.m');

    temp.sim_sig_SrcActiv = sim_sig_SrcActiv;
    temp.sim_sig_IntNoise = sim_sig_IntNoise;
    temp.sim_sig_BcgNoise = sim_sig_BcgNoise;
    temp.sim_sig_MesNoise = sim_sig_MesNoise;
    
    save("tangled.mat");
end