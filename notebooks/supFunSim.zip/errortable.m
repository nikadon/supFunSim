function errortable(MODEL)
    figure('Color', [1, 1, 1]);
    h = heatmap(MODEL.rec_res.table_varN, MODEL.rec_res.table_rowN, table2array(MODEL.rec_res.table));
    h.XLabel = 'Errors';
    h.YLabel = 'Filters';
    h.Title = 'Results';
    h.ColorLimits = [0 3];
end