function model = generatetimeseriesinterferencenoise(SETUP, MODEL)
    % Generates time series interference noise.

    model = MODEL;
    model.sim_sig_IntNoise = model.sim_sig_SrcActiv;

    model.sim_sig_IntNoise.inf = 'MVAR based signal for interference (biological) noise activity sources';
    tmp_IntNoiseCol = 2;

    if SETUP.TELL
        disp('Getting base for IntNoise...');
    end;
    model.sim_sig_IntNoise.sigSRC_pre = -model.sim_sig_IntNoise.sigSRC_pre;
    model.sim_sig_IntNoise.sigSRC_pst = -model.sim_sig_IntNoise.sigSRC_pst;
    [model.sim_sig_IntNoise.w01, model.sim_sig_IntNoise.A01, model.sim_sig_IntNoise.C01, model.sim_sig_IntNoise.SBC01, model.sim_sig_IntNoise.FPE01, model.sim_sig_IntNoise.th01] = deal([]);

    if SETUP.TELL
        disp('Populating signals for IntNoise...');
    end;
    model.sim_sig_IntNoise.sigSRC_pre = repmat(model.sim_sig_IntNoise.sigSRC_pre, 1, ceil( (sum(SETUP.SRCS(:, tmp_IntNoiseCol)) + SETUP.DEEP(1, tmp_IntNoiseCol))/size(model.sim_sig_IntNoise.sigSRC_pre, 2)), 1);
    model.sim_sig_IntNoise.sigSRC_pst = repmat(model.sim_sig_IntNoise.sigSRC_pst, 1, ceil( (sum(SETUP.SRCS(:, tmp_IntNoiseCol)) + SETUP.DEEP(1, tmp_IntNoiseCol))/size(model.sim_sig_IntNoise.sigSRC_pst, 2)), 1);

    if SETUP.TELL
        disp('Reducing dimensionality of IntNoise...');
    end;
    model.sim_sig_IntNoise.sigSRC_pre = model.sim_sig_IntNoise.sigSRC_pre(:, 1:(sum(SETUP.SRCS(:, tmp_IntNoiseCol)) + SETUP.DEEP(1, tmp_IntNoiseCol)), :);
    model.sim_sig_IntNoise.sigSRC_pst = model.sim_sig_IntNoise.sigSRC_pst(:, 1:(sum(SETUP.SRCS(:, tmp_IntNoiseCol)) + SETUP.DEEP(1, tmp_IntNoiseCol)), :);

    if SETUP.TELL
        disp('Backing-up IntNoise before white noise admixture...');
    end;
    model.sim_sig_IntNoise.sigSRC_pre_b4admix = model.sim_sig_IntNoise.sigSRC_pre;
    model.sim_sig_IntNoise.sigSRC_pst_b4admix = model.sim_sig_IntNoise.sigSRC_pst;

    if SETUP.WhtNoiseAddFlg
        if SETUP.TELL
            disp('Adding some white noise to the biological noise activity...');
        end;
        if SETUP.SEED
            rng(SETUP.SEEDS(1));
        end
        model.sim_sig_IntNoise.noiseAdmix_pre = randn(size(model.sim_sig_IntNoise.sigSRC_pre));
        if SETUP.SEED
            rng(SETUP.SEEDS(1));
        end
        model.sim_sig_IntNoise.noiseAdmix_pst = randn(size(model.sim_sig_IntNoise.sigSRC_pst));
        for kk = 1:SETUP.K00
            model.sim_sig_IntNoise.noiseAdmix_pre(:, :, kk) = rawAdjTotSNRdB(model.sim_sig_IntNoise.sigSRC_pre(:, :, kk), model.sim_sig_IntNoise.noiseAdmix_pre(:, :, kk), SETUP.WhtNoiseAddSNR);
            model.sim_sig_IntNoise.noiseAdmix_pst(:, :, kk) = rawAdjTotSNRdB(model.sim_sig_IntNoise.sigSRC_pst(:, :, kk), model.sim_sig_IntNoise.noiseAdmix_pst(:, :, kk), SETUP.WhtNoiseAddSNR);
        end
        model.sim_sig_IntNoise.sigSRC_pre = model.sim_sig_IntNoise.sigSRC_pre + model.sim_sig_IntNoise.noiseAdmix_pre;
        model.sim_sig_IntNoise.sigSRC_pst = model.sim_sig_IntNoise.sigSRC_pst + model.sim_sig_IntNoise.noiseAdmix_pst;
    end

    if SETUP.TELL
        disp('Fitting MVAR model to generated signal...');
    end;
    [model.sim_sig_IntNoise.w01, model.sim_sig_IntNoise.A01, model.sim_sig_IntNoise.C01, model.sim_sig_IntNoise.SBC01, model.sim_sig_IntNoise.FPE01, model.sim_sig_IntNoise.th01] = arfit(model.sim_sig_IntNoise.sigSRC_pst, model.sim_sig_IntNoise.P00 - round(model.sim_sig_IntNoise.P00/2), model.sim_sig_IntNoise.P00 + round(model.sim_sig_IntNoise.P00/2));
    model.sim_sig_IntNoise.w01 = model.sim_sig_IntNoise.w01;
    model.sim_sig_IntNoise.A01 = model.sim_sig_IntNoise.A01;
    model.sim_sig_IntNoise.C01 = model.sim_sig_IntNoise.C01;
    model.sim_sig_IntNoise.SBC01 = model.sim_sig_IntNoise.SBC01;
    model.sim_sig_IntNoise.FPE01 = model.sim_sig_IntNoise.FPE01;
    model.sim_sig_IntNoise.th01 = model.sim_sig_IntNoise.th01;

    if SETUP.DEBUG
       model.sim_sig_IntNoise = rmfield(model.sim_sig_IntNoise, {'sigSRC_pre_b4admix', 'sigSRC_pst_b4admix', 'noiseAdmix_pre', 'noiseAdmix_pst'})
    end
end