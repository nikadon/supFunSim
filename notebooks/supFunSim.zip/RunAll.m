
parameters = EEGParameters().generate();

filters = [ "LCMV", "MMSE", "ZF", "RANDN", "ZEROS", "EIG-LCMV", ...
            "sMVP_MSE", "sMVP_R", "sMVP_N", "sMVP_NL_MSE", ...
            "sMVP_NL_R", "sMVP_NL_N", "NL" ];

reconstruction = EEGReconstruction();
reconstruction = reconstruction.init();

for np = 1:1%length(parameters)
    parameter = parameters(np);
    reconstruction = reconstruction.setparameters(parameter);
    reconstruction = reconstruction.setsignals();
    reconstruction = reconstruction.setleadfields();
    reconstruction = reconstruction.setpreparations();
    reconstruction = reconstruction.setfilters(filters);
    reconstruction.save();
end

reconstruction = printaverageresults(reconstruction);

eegplot = EEGPlotting(reconstruction)

%plot inline
eegplot.plotMVARmodelcoefficientmatrixmask()

%plot native
eegplot.plotPDCgraph()

%plot inline
eegplot.plotMVARmodelcoefficientmatrixgraph()

%plot inline
eegplot.ploterrortable()

%plot native
figure('Color', [1, 1, 1]);
eegplot.plotdeepsourcesasicosahedron642();

%plot native
eegplot.plotdeepsourcesasthalami();

%plot native
eegplot.plotcortexmesh();

%plot native
eegplot.plotbrainoutermesh();

%plot native
eegplot.plotskulloutermesh();

%plot native
eegplot.plotscalpoutermesh();

%plot native
eegplot.plotelectrodepositioning();

%plot native
eegplot.plotelectrodelabels();

%plot native
eegplot.plotROIvisualization();

%plot native
eegplot.plotsourcevisualization();

eegtest = EEGTest()

eegtest = eegtest.testsetup()

eegtest = eegtest.testsignals()

eegtest = eegtest.testleadfields()

eegtest = eegtest.testfilters()

eegtest = eegtest.testerrors()
