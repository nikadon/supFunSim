function model = prepareleadfieldconfiguration(SETUP, MODEL)
    % Lead-field configuration according to perturbation settings
    % and reducing rank of lead-field matrix of interfering sources.

    model = MODEL;
    % Note: in this and functions subsections we aim at following closely notation from the paper.

    % H_Src taken from FieldTrip
    if SETUP.H_Src_pert
        model.H_Src = model.sim_lfg_SrcActiv_pert.LFG;
    else
        model.H_Src = model.sim_lfg_SrcActiv_orig.LFG;
    end

    % H_Int taken from FieldTrip
    if SETUP.H_Int_pert
        model.H_Int = model.sim_lfg_IntNoise_pert.LFG;
    else
        model.H_Int = model.sim_lfg_IntNoise_orig.LFG;
    end

    % reduced-rank lead-field for patch constraints
    [model.U_model.H_Int model.Si_model.H_Int model.V_model.H_Int] = svd(model.H_Int);

    for ii = SETUP.IntLfgRANK + 1:size(model.H_Int, 2)
        model.Si_model.H_Int(ii, ii) = 0;
    end

    model.H_Int = model.U_model.H_Int * model.Si_model.H_Int * model.V_model.H_Int';
end