function model = calculate_P_sMVP_MSE_opt(MODEL)
    % Definition of P_sMVP(MSE) projection.

    model = MODEL;
    
    % note: pinv(model.H_Src_R)*pinv(model.H_Src_R)' = pinv(S)
    model.K_MSE = pinv(model.S) - 2*model.C;
    [model.U_K_MSE, model.W_K_MSE] = eig(model.K_MSE);
    [~, model.p_K_MSE] = sort(diag(model.W_K_MSE));
    % note: for selecting optimal rank, Theobald's Theorem from
    % M. Theobald. *An inequality for the trace of the product of
    % two symmetric matrices*. Volume 77, Issue 2 March 1975, pp. 265-267
    % can be used without evaluation of the cost function, or it can be
    % done as here:
    model.U_K_MSE = model.U_K_MSE(:, model.p_K_MSE);
    model.sMVP_MSE_ranks = zeros(1, size(model.H_Src, 2));

    for jj = 1:size(model.H_Src, 2)
        model.sMVP_MSE_ranks(jj) = trace(model.U_K_MSE(:, 1:jj) * model.U_K_MSE(:, 1:jj)' * model.K_MSE);
    end

    [~, model.sMVP_MSE_rank_opt] = min(model.sMVP_MSE_ranks);
    % _opt stands for optimal
    model.P_sMVP_MSE_opt = model.U_K_MSE(:, 1:model.sMVP_MSE_rank_opt) * model.U_K_MSE(:, 1:model.sMVP_MSE_rank_opt)';
end