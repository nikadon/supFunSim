function rawPlotA00(A00)

    SETUP.PDC_RES = [0:0.01:0.5];
    rawPlotPDC(abs(PDC(A00, SETUP.PDC_RES)), SETUP.PDC_RES);
end