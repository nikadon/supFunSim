classdef EEGForwardModel < EEGSignalGenerator
    % By methods in this class we obtain signals in the space of the electrodes, i.e.
    % the sources project on electrodes by multiplying the matrix of signals
    % by the leadfield matrix. This way one gets signals on the electrodes,
    % which already contains noise from the background and interference sources.
    % The only noise that does not come from this operation is the measurement noise.
    %
    % EEGForwardModel Properties:
    %    SETUP - setup for simulation,
    %    MODEL - model variables.
    %
    % EEGForwardModel Methods:
    %    setleadfields - calculating leadfields.
    
    properties(GetAccess='public', SetAccess='public')
        % Properties of the class
    end

    methods
        function obj = EEGForwardModel()
            % Constructor of the EEGForwardModel class
        end
        function obj = setleadfields(obj)
            % Set leadfields.

            obj.MODEL = geometryrandomsampling(obj.SETUP, obj.MODEL, obj.MATS);
            obj.MODEL = geometryindices(obj.SETUP, obj.MODEL, obj.MATS);
            obj.MODEL = geometrycoordinates(obj.SETUP, obj.MODEL, obj.MATS);
            obj.MODEL = geometrydeepsources(obj.SETUP, obj.MODEL, obj.MATS);
            obj.MODEL = geometryperturbation(obj.SETUP, obj.MODEL, obj.MATS);
            obj.MODEL = geometryleadfieldscomputation(obj.SETUP, obj.MODEL, obj.MATS);
            obj.MODEL = forwardmodeling(obj.SETUP, obj.MODEL);
        end
        function obj = setpreparations(obj)
            % Creates signal from source activities, background and interference noise by
            % utilizing signal to noise ratio.

            obj.MODEL = preparesnrsadjustment(obj.SETUP, obj.MODEL);
            obj.MODEL = prepareleadfieldconfiguration(obj.SETUP, obj.MODEL);
            obj.MODEL = preparemeasuredsignals(obj.SETUP, obj.MODEL);
        end        
    end
end