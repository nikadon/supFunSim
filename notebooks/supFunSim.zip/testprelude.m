function SETUP = testprelude()
    % Importing code generated from Org-mode files.

    run('./tangled/tg_s07_BATCH___01_Prelude.m');
    save("tangled.mat"); % Locally save all variable names and values
end