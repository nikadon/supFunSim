function SETUP = generatedummysetup()

    % Basic SETUP which sets all parameters to default values. 
    % Please do not alter these lines.    
    SETUP = [];  
    SETUP = setinitialvalues(SETUP); 
    SETUP = setsnrvalues(SETUP);
  
    % Smartparameters modifies most commonly used simulation parameters: 
    % number of and ROIs of sources, Pre and Pst signal components, etc.
    % These parameters may be modified by the user within the body of smartparameters(SETUP) function
    % or given directly below.
    SETUP = configurationparameters(SETUP);
    
    % Parameters prepared for unit tests which validate but does not affect simulations.
    % Comment this if you want to use your own parameters set in `smartparameters`.
    %SETUP = testparameters(SETUP);
end