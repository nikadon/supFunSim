function PDC4(SETUP, MODEL)

    close all
    figure(100);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    cccSim___rawPlotA00(MODEL.sim_sig_SrcActiv.A00);
    set(gcf, 'color', 'w');
    figure(101);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    cccSim___rawPlotA00(MODEL.sim_sig_SrcActiv.A01);
    set(gcf, 'color', 'w');
    figure(130);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    cccSim___rawPlotA00(MODEL.sim_sig_IntNoise.A00);
    set(gcf, 'color', 'w');
    figure(131);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    cccSim___rawPlotA00(MODEL.sim_sig_IntNoise.A01);
    set(gcf, 'color', 'w');
end