function MVARzeroingmatrix(SETUP, MODEL)

    figure(101);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    imagesc(MODEL.sim_sig_SrcActiv.M00);
    colormap(rawHotColdColorMap(10));
    colorbar;
    set(gcf, 'color', 'w');
end