function model = spatialfiltering(SETUP, MODEL, filter)
    % Definition of all filters.

    model = MODEL;

    switch filter
    
        case "LCMV"
            % note: S and G use only model.H_Src, as we want to recover
            % only activity of interest, not interference 
            model = calculate_LCMV_R(model)
            model = calculate_LCMV_N(model)
        
        case "MMSE"
            %  MMSE filter
            model.rec_flt.MMSE = model.C * model.H_Src' * pinv(model.R);
            
        case "ZF"
            model.rec_flt.ZF = pinv(model.H_Src);
            
        case "RANDN"
            model.rec_flt.RANDN = randn(size(model.H_Src'));
            
        case "ZEROS"
            model.rec_flt.ZEROS = zeros(size(model.H_Src'));

        case "EIG-LCMV"
            %  EIG-LCMV filter
            [model.UR, model.SiR, ~] = svd(model.R);
            model.P_EIG = model.UR(:, 1:SETUP.RANK_EIG) * model.UR(:, 1:SETUP.RANK_EIG)';

            model = calculate_LCMV_R(model)
            model = calculate_LCMV_N(model)
            
            model.rec_flt.EIG_LCMV_R = model.rec_flt.LCMV_R * model.P_EIG;
            model.rec_flt.EIG_LCMV_N = model.rec_flt.LCMV_N * model.P_EIG;

        case "sMVP_MSE"
            % sMVP_MSE filter
            % note: S and G use only model.H_Src, as we want to recover only
            % activity of interest, not interference
            % note: pinv(model.H_Src_R)*pinv(model.H_Src_R)' = pinv(S)
            model = calculate_LCMV_R(model)
            model = calculate_P_sMVP_MSE_opt(model)
            model.rec_opt.ranks.sMVP_MSE = model.sMVP_MSE_rank_opt;
            model.rec_flt.sMVP_MSE = model.P_sMVP_MSE_opt * model.rec_flt.LCMV_R;

        case "sMVP_R"
            % sMVP_R filter
            % note: S and G use only model.H_Src, as we want to recover only
            % activity of interest, not interference
            % note: pinv(model.H_Src_R)*pinv(model.H_Src_R)' = pinv(S)
            model = calculate_LCMV_R(model)
            model = calculate_P_sMVP_R_opt(model)
            model.rec_opt.ranks.sMVP_R = model.sMVP_R_rank_opt;
            model.rec_flt.sMVP_R = model.P_sMVP_R_opt * model.rec_flt.LCMV_R;

        case "sMVP_N"
            % sMVP_N filter
            % note: S and G use only model.H_Src, as we want to recover only
            % activity of interest, not interference
            % note: pinv(model.H_Src_N)*pinv(model.H_Src_N)' = pinv(G)
            model = calculate_LCMV_N(model)
            model = calculate_P_sMVP_N_opt(model)
            model.rec_opt.ranks.sMVP_N = model.sMVP_N_rank_opt;
            model.rec_flt.sMVP_N = model.P_sMVP_N_opt * model.rec_flt.LCMV_N;

        case "sMVP_NL_MSE"
            % sMVP-NL filters
            model = calculate_H_Src(model)
            model = calculate_H_Int(model)
            model = calculate_sMVP_NL(model)

            % sMVP_NL_MSE filter
            model = calculate_sMVP_NL_MSE(model)

        case "sMVP_NL_R"
            % sMVP-NL filters
            model = calculate_H_Src(model)
            model = calculate_H_Int(model)
            model = calculate_sMVP_NL(model)
        
            % sMVP_NL_R filter
            model = calculate_sMVP_NL_R(model)

        case "sMVP_NL_N"
            % sMVP-NL filters
            model = calculate_H_Src(model)
            model = calculate_H_Int(model)
            model = calculate_sMVP_NL(model)
            
            % sMVP_NL_N filter
            model = calculate_sMVP_NL_N(model)

        otherwise
            % NL filter as proposed in Hui & Leahy 2010
            model = calculate_H_Src(model)
            model = calculate_H_Int(model)

            model.H_SrcInt = [model.H_Src model.H_Int];
            P_NL = [eye(size(model.H_Src, 2)) zeros(size(model.H_Src, 2), size(model.H_Int, 2))];
            
            model.rec_flt.NL = P_NL * pinv(model.H_SrcInt' * pinv(model.R) * model.H_SrcInt) * model.H_SrcInt' * pinv(model.R);
    end
    
    if(SETUP.fltREMOVE) && (isfield(model.rec_flt, 'ZF'))
        model.rec_flt = rmfield(model.rec_flt, 'ZF');
    end
    if(SETUP.fltREMOVE) && (isfield(model.rec_flt, 'RANDN'))
        model.rec_flt = rmfield(model.rec_flt, 'RANDN');
    end
    if(SETUP.fltREMOVE) && (isfield(model.rec_flt, 'ZEROS'))
        model.rec_flt = rmfield(model.rec_flt, 'ZEROS');
    end

end