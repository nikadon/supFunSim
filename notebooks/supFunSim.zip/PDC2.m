function PDC2(SETUP, MODEL)

    figure(120);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    cccSim___rawPlotA00(MODEL.sim_sig_SrcActiv.A00);
    set(gcf, 'color', 'w');

    figure(121);
    clf;
    set(gcf,'Position', SETUP.DISP);
    cccSim___rawPlotA00(MODEL.sim_sig_SrcActiv.A01);
    set(gcf, 'color', 'w');
end