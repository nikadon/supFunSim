function temp = testspatialfiltering()
    % Importing code generated from Org-mode files.

    load("tangled.mat");

    run('./tangled/tg_s04_Preparation___00_SNRs_Adjustment.m');
    run('./tangled/tg_s04_Preparation___01_Signal_Covariances.m');
    run('./tangled/tg_s05_Spatial_filtering___01_Preparation.m');
    run('./tangled/tg_s05_Spatial_filtering___02_Definitions.m');
    run('./tangled/tg_s05_Spatial_filtering___03_Execution.m');
    run('./tangled/tg_s06_Error_evaluation.m');
    
    clear temp;
    
    temp.rec_opt = rec_opt;
    temp.rec_flt = rec_flt;
    temp.rec_sig = rec_sig;
    
    save("tangled.mat");
end