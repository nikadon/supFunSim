function model = spatialfilteringexecution(SETUP, MODEL)
    % Reconstruction of source signals using spatial filter and
    % fitting MVAR to the reconstructed signal.

    model = MODEL;
    
    model.rec_sig.Original = model.sim_sig_SrcActiv.sigSRC_pst;
    model.rec_sig.Dummy = model.sim_sig_SrcActiv.sigSRC_pre;
    tmp_fltFields = fieldnames(model.rec_flt);

    for nn = 1:length(tmp_fltFields) % For all filters
        for kk = 1:SETUP.K00 % For each realisation
            model.rec_sig.(tmp_fltFields{nn})(:, :, kk) = (model.rec_flt.(tmp_fltFields{nn}) * model.y_Pst(:, :, kk)')'; % We reconstruct basing on y_Pst
        end
    end
    
    model.rec_funDep_A00.Original = model.sim_sig_SrcActiv.A00;

    [~, model.rec_funDep_A00.Dummy, ~, ~, ~, ~] = arfit(model.sim_sig_SrcActiv.sigSRC_pre, model.sim_sig_SrcActiv.P00, model.sim_sig_SrcActiv.P00);

    for nn = 1:length(tmp_fltFields)
        [~, model.rec_funDep_A00.(tmp_fltFields{nn}), ~, ~, ~, ~] = arfit(model.rec_sig.(tmp_fltFields{nn}), SETUP.P00,SETUP.P00);
    end

    tmp_allFields = fieldnames(model.rec_funDep_A00);
    for nn = 1:length(tmp_allFields)
        model.rec_funDep_PDC.(tmp_allFields{nn}) = abs(PDC(model.rec_funDep_A00.(tmp_allFields{nn}), SETUP.PDC_RES));
    end
end