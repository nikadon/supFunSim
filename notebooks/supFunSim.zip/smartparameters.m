function SETUP = smartparameters(setup)
    % Setup created for a particular experiment.

    SETUP = setup;
    
    SETUP.SEED   = 0; % If you want to set SEED
    SETUP.ERPs   = 0;

    SETUP.rROI   = logical(1);    % random (1) or predefined (0) ROIs
    SETUP.rPNT   = logical(1);    % random (1) or predefined (0) candidate points for source locations: 
    SETUP.SRCS   = []; % Cortical sources (avoid placing more than 10 sources in single ROI)
    SETUP.SRCS   = [ SETUP.SRCS;  3  0  0 ];
    SETUP.SRCS   = [ SETUP.SRCS;  4  0  0 ];
    SETUP.SRCS   = [ SETUP.SRCS;  2  0  3 ];
    SETUP.SRCS   = [ SETUP.SRCS;  0  2  3 ];
    SETUP.DEEP   = [              1  0  3 ]; % deep sources
    SETUP.K00    = 1;      % number of independent realizations of signal and noise based on generated MVAR model
    
    SETUP.SBNR_RNG       = repmat(5, 10); %[5,5,5,5,5]; % signal to biological noise power ratio expressed in dB (both measured on electrode level)
    SETUP.WhtNoiseAddFlg = 1;   % white noise admixture in biological noise interference noise (FLAG)
    SETUP.WhtNoiseAddSNR = 3;   % SNR of BcgNoise and WhiNo (dB)
    SETUP.SigPre = 0;   SETUP.IntPre = 0;   SETUP.BcgPre = 1;   SETUP.MesPre = 1; % final signal components for pre-interval  (use zero or one for signal, interference noise, biological noise, measurement noise)
    SETUP.SigPst = 1;   SETUP.IntPst = 1;   SETUP.BcgPst = 1;   SETUP.MesPst = 1; % final signal components for post-interval (as above)
    SETUP.n00    = 2000;
end