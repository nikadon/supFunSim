classdef EEGTest < EEGParameters & EEGReconstruction
    methods
        function obj = EEGTest()
            % % Constructor of EEGTest class
        end
        function obj = testsetup(obj)
            % Test for equality of SETUPs.

            % From new code
            parameters = obj.generate();
            obj = obj.init();
            obj = obj.setparameters(parameters(1));
            
            % From original code
            SETUP = testprelude();
            
            % Test
            [common, d1, d2] = comp_struct(obj.SETUP, SETUP)
            % Fileds sel_msh, sel_geo_deep_thalami, sel_geo_deep_icosahedron642,
            % sel_atl, sel_vol, sel_ele, sel_src, thalamus, DEBUG, SINR,
            % rngMesNoise, rngBcgNoise, rngIntNoise, DATE, NAME, totSimCount,
            % rngSimCount, ActivityInd were added to EEGSImulation so that
            % there may not be in SETUP and everything is OK.
            
            extrafields = {'thalamus', 'DEBUG', 'SINR', 'DATE', 'NAME', 'PATH', 'SINR_RNG', 'SBNR_RNG', 'SMNR_RNG'};
            if isempty(setdiff(fieldnames(d1), extrafields)) && isempty(d2)
                disp('>>>   TEST FOR SETUP PREPARATION DONE PROPERLY!');
            else
                error('<<<   ERROR DURING TESTING SETUP PREPARATION!');
            end
        end
        function obj = testsignals(obj)
            % Test for equality of generated signals.

            % From new code
            obj = obj.setsignals();
            
            % From original code
            temp = testtimeseries();

            [common, d1, d2] = comp_struct(obj.MODEL, temp)
                        
            if isempty(d1) && isempty(d2)
                disp(">>>   TEST FOR SIGNAL GENERATION DONE PROPERLY!");
            else
                error('<<<   ERROR DURING TESTING SIGNAL GENERATION!');
            end
        end
        function obj = testleadfields(obj)
            % Test for equality of lead-fields.

            % From new code
            obj = obj.setleadfields();
            
            % From original code
            temp = testgeometry();
            
            %[common, d1, d2] = comp_struct(obj.MODEL, temp)
            
            model_test = obj.MODEL;
            temp_test = temp;
            
            % We have to remove all fields, which are inherently
            % differet, i.e. proctime, pwd etc.
            model_test.sim_lfg_SrcActiv_orig.lfg.cfg = rmfield(model_test.sim_lfg_SrcActiv_orig.lfg.cfg, 'callinfo');
            temp_test.sim_lfg_SrcActiv_orig.lfg.cfg = rmfield(temp_test.sim_lfg_SrcActiv_orig.lfg.cfg, 'callinfo');
            model_test.sim_lfg_SrcActiv_pert.lfg.cfg = rmfield(model_test.sim_lfg_SrcActiv_pert.lfg.cfg, 'callinfo');
            temp_test.sim_lfg_SrcActiv_pert.lfg.cfg = rmfield(temp_test.sim_lfg_SrcActiv_pert.lfg.cfg, 'callinfo');
            
            model_test.sim_lfg_IntNoise_orig.lfg.cfg = rmfield(model_test.sim_lfg_IntNoise_orig.lfg.cfg, 'callinfo');
            temp_test.sim_lfg_IntNoise_orig.lfg.cfg = rmfield(temp_test.sim_lfg_IntNoise_orig.lfg.cfg, 'callinfo');
            model_test.sim_lfg_IntNoise_pert.lfg.cfg = rmfield(model_test.sim_lfg_IntNoise_pert.lfg.cfg, 'callinfo');
            temp_test.sim_lfg_IntNoise_pert.lfg.cfg = rmfield(temp_test.sim_lfg_IntNoise_pert.lfg.cfg, 'callinfo');
            
            model_test.sim_lfg_BcgNoise_orig.lfg.cfg = rmfield(model_test.sim_lfg_BcgNoise_orig.lfg.cfg, 'callinfo');
            temp_test.sim_lfg_BcgNoise_orig.lfg.cfg = rmfield(temp_test.sim_lfg_BcgNoise_orig.lfg.cfg, 'callinfo');
            model_test.sim_lfg_BcgNoise_pert.lfg.cfg = rmfield(model_test.sim_lfg_BcgNoise_pert.lfg.cfg, 'callinfo');
            temp_test.sim_lfg_BcgNoise_pert.lfg.cfg = rmfield(temp_test.sim_lfg_BcgNoise_pert.lfg.cfg, 'callinfo');
            
            %[common, d1, d2] = comp_struct(obj.MODEL.sim_lfg_SrcActiv_orig, temp.sim_lfg_SrcActiv_orig)
            [common, d1, d2] = comp_struct(model_test.sim_lfg_SrcActiv_orig.lfg.cfg, temp_test.sim_lfg_SrcActiv_orig.lfg.cfg)
            
            if isempty(d1) && isempty(d2)
                disp(">>>   TEST FOR LEADFIELD COMPUTATION DONE PROPERLY!");
            else
                error('<<<   ERROR DURING TESTING SETUP PREPARATION!');
            end
        end
        function obj = testfilters(obj)
            % Test for equality of calculated filters.

            % From new code
            filters = [ "LCMV", "MMSE", "ZF", "RANDN", "ZEROS", "EIG-LCMV", ...
            "sMVP_MSE", "sMVP_R", "sMVP_N", "sMVP_NL_MSE", ...
            "sMVP_NL_R", "sMVP_NL_N", "NL" ];
            obj = obj.setpreparations();
            obj = obj.setfilters(filters);
            model_test = [];
            model_test.rec_opt = obj.MODEL.rec_opt;
            model_test.rec_flt = obj.MODEL.rec_flt;
            model_test.rec_sig = obj.MODEL.rec_sig;
            
            % From original code
            temp_test = testspatialfiltering();
            
            [common, d1, d2] = comp_struct(model_test, temp_test)
            
                        
            if isempty(d1) && isempty(d2)
                disp(">>>   TEST FOR FILTERS DONE PROPERLY!");
            else
                error('<<<   ERROR DURING TESTING FILTERS!');
            end
        end
        function obj = testerrors(obj)
            % Test for equality of calculated errors.

            load("tangled.mat");

            model_table = obj.MODEL.rec_res.table
            temp_table = rec_res.table

            if (isequal(sortrows(model_table), sortrows(temp_table)))
                disp(">>>   TEST FOR ERRORS DONE PROPERLY!");
            else
                error('<<<   ERROR DURING TESTING ERRORS!');
            end 
        end 
    end
end