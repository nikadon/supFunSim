function model = spatialfilteringerrorevaluation(SETUP, MODEL)
    % Error evaluation using Euclidan and Correlation Coefficients.

    model = MODEL;
    
    tmp_allFields  = fieldnames(model.rec_sig);

    % Preparation
    for nn = 1:length(tmp_allFields)
      for ii = 1:SETUP.n00
          for jj = 1:SETUP.K00
              model.rec_sig.(tmp_allFields{nn})(ii, :, jj) = model.rec_sig.(tmp_allFields{nn})(ii, :, jj) / norm(model.rec_sig.(tmp_allFields{nn})(ii, :, jj));
          end
      end
    end
    
    % Euclid for signal
    for nn = 1:length(tmp_allFields)
      tmp_error = zeros(SETUP.n00, SETUP.K00);
      for ii = 1:SETUP.n00
          for jj = 1:SETUP.K00
              tmp_error(ii, jj) = norm(model.rec_sig.(tmp_allFields{1})(ii, :, jj) - model.rec_sig.(tmp_allFields{nn})(ii, :, jj))^2;                  
          end
      end
      model.rec_sigAmp_ErrEuclid.(tmp_allFields{nn}) = mean(mean(tmp_error));
    end

    % CorrCf for signal
    for nn = 1:length(tmp_allFields)
      tmp_error = zeros(sum(SETUP.SRCS(:, 1)), SETUP.K00);
      for kk = 1:sum(SETUP.SRCS(:, 1))
          for jj = 1:SETUP.K00
              tmp_x = corrcoef(model.rec_sig.(tmp_allFields{1})(:, kk, jj), model.rec_sig.(tmp_allFields{nn})(:, kk, jj));
              tmp_error(kk, jj) = tmp_x(1, end);
          end
      end
      model.rec_sigAmp_ErrCorrCf.(tmp_allFields{nn}) = mean(mean(tmp_error));
    end

    % Euclid for MVAR coefficients matrix
    for nn = 1:length(tmp_allFields)
      model.rec_funDep_A00_ErrEuclid.(tmp_allFields{nn}) = (norm(model.rec_funDep_A00.(tmp_allFields{1}) - model.rec_funDep_A00.(tmp_allFields{nn}), 'fro')^2);
    end

    % CorrCf for MVAR coefficient matrix
    for nn = 1:length(tmp_allFields)
      tmp_error = zeros(sum(SETUP.SRCS(:, 1)), 1);
      for kk = 1:sum(SETUP.SRCS(:, 1))
          tmp_x = corrcoef(model.rec_funDep_A00.(tmp_allFields{1})(kk, :), model.rec_funDep_A00.(tmp_allFields{nn})(kk, :));
          tmp_error(kk) = tmp_x(1, end);
      end
      model.rec_funDep_A00_ErrCorrCf.(tmp_allFields{nn}) = mean(tmp_error);
    end

    % Euclid for PDC coefficient matrix
    for nn = 1:length(tmp_allFields)
      tmp_error = zeros(sum(SETUP.SRCS(:,1)),1);
      for ii = 1:sum(SETUP.SRCS(:, 1))
          tmp_error(ii) = norm(squeeze(model.rec_funDep_PDC.(tmp_allFields{1})(ii, :, :)) - squeeze(model.rec_funDep_PDC.(tmp_allFields{nn})(ii, :, :)), 'fro')^2;
      end
      model.rec_funDep_PDC_ErrEuclid.(tmp_allFields{nn}) = mean(tmp_error);
    end

    % CorrCf for PDC coefficient matrix
    for nn = 1:length(tmp_allFields)
      tmp_error = zeros(sum(SETUP.SRCS(:, 1)), 1);
      for ii = 1:sum(SETUP.SRCS(:, 1))
          tmp_x = corrcoef(reshape(squeeze(model.rec_funDep_PDC.(tmp_allFields{1})(ii, :, :)), [], 1), reshape(squeeze(model.rec_funDep_PDC.(tmp_allFields{nn})(ii, :, :)), [], 1));
          tmp_error(ii) = tmp_x(1, end);
      end
      model.rec_funDep_PDC_ErrCorrCf.(tmp_allFields{nn}) = mean(tmp_error);
    end
end