function model = calculate_sMVP_NL_N(MODEL)
    % Definition of sMVP_NL_N filter.

    model = MODEL;
    
    model.K_NL_MSE_N = pinv(model.P_sMVP_NL_N * model.H_Src_N) * model.P_sMVP_NL_N * (pinv(model.P_sMVP_NL_N * model.H_Src_N))' - model.C_NL;

    %K_NL_N = pinv(model.P_sMVP_NL_N * model.H_Src_N) * model.P_sMVP_NL_N * (pinv(model.P_sMVP_NL_N * model.H_Src_N))';
    model.K_NL_N = model.K_NL_MSE_N + model.C_NL;
    [model.U_K_NL_N, model.W_K_NL_N] = eig(model.K_NL_N);
    [~, model.p_K_NL_N] = sort(diag(model.W_K_NL_N));
    model.U_K_NL_N = model.U_K_NL_N(:, model.p_K_NL_N);
    model.sMVP_NL_N_ranks = zeros(1, size(model.H_Src, 2));

    for jj = 1:size(model.H_Src, 2)
        % cost function
        model.sMVP_NL_N_ranks(jj) = trace(model.U_K_NL_N(:, 1:jj) * model.U_K_NL_N(:, 1:jj)' * model.K_NL_MSE_N);
    end

    [~, model.sMVP_NL_N_rank_opt] = min(model.sMVP_NL_N_ranks);
    % note the simplified notation for P_N_opt
    model.P_sMVP_NL_N_opt = model.U_K_NL_N(:, 1:model.sMVP_NL_N_rank_opt) * model.U_K_NL_N(:, 1:model.sMVP_NL_N_rank_opt)';

    model.rec_opt.ranks.sMVP_NL_N = model.sMVP_NL_N_rank_opt;

    model.rec_flt.sMVP_NL_N = model.P_sMVP_NL_N_opt * pinv(model.P_sMVP_NL_N * model.H_Src_N) * model.P_sMVP_NL_N * pinv(sqrtm(model.N));
end