function SETUP = providepathstonecessarytoolboxes(varargin)
    % PROVIDEPATHSTONECESSARYTOOLBOXES adds path to directories containing
    % necessary toolboxes and handy functions.  If no argument is provided
    % toolbox directories are expected to be subdirectories of the
    % '~/toolboxes/' directory.  A path to other directory can be
    % specified as a string argument.
    %
    % Toolboxes: arfit, fieldtrip
    %
    % Usage:
    %
    %   providepathstonecessarytoolboxes()
    %
    % or
    %
    %   providepathstonecessarytoolboxes('/path/to/directory/contining/toolboxes/')

    switch length(varargin)
       case 0
          TMP_TOOLB_PATH = '~/toolboxes/';
       case 1
          TMP_TOOLB_PATH = varargin{1};
       otherwise
          error('supFunSim:: providetoolboxesetc requires at most one optional input.');
    end;
    if exist(TMP_TOOLB_PATH, 'dir') ~= 7
        error(['supFunSim:: providetoolboxesetc toolboxes directory (', TMP_TOOLB_PATH,') was not found.']);
    end;
    disp(['supFunSim:: looking for toolboxes in: ', TMP_TOOLB_PATH])

    addpath([TMP_TOOLB_PATH, '/arfit', filesep]);

    addpath([TMP_TOOLB_PATH, 'fieldtrip', filesep]);
    % addpath([TMP_TOOLB_PATH, 'fieldtrip', filesep, 'private', filesep]);

    addpath([TMP_TOOLB_PATH, 'fieldtrip', filesep, 'forward', filesep]);
    % addpath([TMP_TOOLB_PATH, 'fieldtrip', filesep, 'forward', filesep, 'privatePublic', filesep]);

    addpath([TMP_TOOLB_PATH, 'fieldtrip', filesep, 'utilities']);
    % addpath([TMP_TOOLB_PATH, 'fieldtrip', filesep, 'utilities', filesep, 'private', filesep]);
    % copyfile([TMP_TOOLB_PATH, 'fieldtrip', filesep, 'utilities', filesep, 'private', filesep], [TMP_TOOLB_PATH, 'fieldtrip', filesep, 'utilities', filesep, 'privatePublic', filesep]);

    addpath([TMP_TOOLB_PATH, 'aux_supFunSim/' ]);

    ft_defaults;

end