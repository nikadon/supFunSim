function model = calculate_sMVP_NL(MODEL)
    % Auxiliary matrices used in filter definitions.

    model = MODEL;
    
    model.P_sMVP_NL_R = eye(size(model.H_Int_R, 1)) - model.H_Int_R * pinv(model.H_Int_R);
    model.P_sMVP_NL_N = eye(size(model.H_Int_N, 1)) - model.H_Int_N * pinv(model.H_Int_N);
end