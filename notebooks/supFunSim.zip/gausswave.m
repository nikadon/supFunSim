function gausswave(SETUP, MODEL)

    figure
    imagesc(MODEL.sim_sig_SrcActiv.sigSRC_pst_orig(:, :, 1))
    figure
    imagesc(MODEL.sim_sig_SrcActiv.sigSRC_pst(:, :, 1))
    figure
    imagesc(MODEL.sim_sig_SrcActiv.ERPs_pst(:, :, 1))

    ee = 0
    ee = ee + 1

    tmp_LB = -5;
    tmp_UB = 7;
    tmp_NN = SETUP.n00;
    tmp_PP = mod(ee, 3) + 1;

    tmp_PP

    [PSI,X] = gauswavf(tmp_LB, tmp_UB, tmp_NN, tmp_PP);

    plot(PSI)

    size(cat(2, 20*repmat(transpose(MODEL.sim_sig_SrcActiv.ERPs), [1, 1, SETUP.K00]), zeros(SETUP.n00, sum(SETUP.SRCS(:, 1)) - SETUP.ERPs,SETUP.K00)))

    figure
    plot(MODEL.sim_sig_SrcActiv.ERPs(3, :))

    figure
    plot(MODEL.sim_sig_SrcActiv.sigSRC_pst(:, 3, 1))

    figure
    plot(mean(MODEL.sim_sig_SrcActiv.sigSRC_pst(:, 3, :), 3))
end