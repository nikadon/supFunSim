function model = generatetimeseriessourceactivity(SETUP, MODEL)
    % If required, adds ERP deterministic signal to the signal of interest.

    model = MODEL;
    model.sim_sig_SrcActiv = cccSim___makeSimSig(SETUP, 1, 'MVAR based signal for sources activity');

    if SETUP.ERPs > 0
        model.sim_sig_SrcActiv.sigSRC_pst_orig = model.sim_sig_SrcActiv.sigSRC_pst;
        model.sim_sig_SrcActiv.sigSRC_pre_orig = model.sim_sig_SrcActiv.sigSRC_pre;

        tmp_LB = -5;
        tmp_UB = 7;
        tmp_NN = SETUP.n00;
        tmp_PP = 1;
        for ee = 1:1:SETUP.ERPs
            tmp_PP = mod(ee, 3) + 1;
            model.sim_sig_SrcActiv.ERPs(ee, :) = gauswavf(tmp_LB, tmp_UB, tmp_NN, tmp_PP);
        end
        model.sim_sig_SrcActiv.ERPs_pst = transpose(model.sim_sig_SrcActiv.ERPs);
        model.sim_sig_SrcActiv.ERPs_pst(size(model.sim_sig_SrcActiv.sigSRC_pst, 1), size(model.sim_sig_SrcActiv.sigSRC_pst, 2)) = 0;
        model.sim_sig_SrcActiv.ERPs_pst = cat(3, repmat(model.sim_sig_SrcActiv.ERPs_pst, [1, 1, SETUP.K00]));

        model.sim_sig_SrcActiv.sigSRC_pst = model.sim_sig_SrcActiv.sigSRC_pst + 20 * model.sim_sig_SrcActiv.ERPs_pst;
    end
end