function model = forwardmodeling(SETUP, MODEL)
    % Forward modeling (lead-field multiplicated by signals in source space).

    model = MODEL;
    
    for kk = 1:SETUP.K00
        model.sim_sig_SrcActiv.sigSNS_pre(:, :, kk) = (model.sim_lfg_SrcActiv_orig.LFG * model.sim_sig_SrcActiv.sigSRC_pre(:, :, kk)')';
        model.sim_sig_SrcActiv.sigSNS_pst(:, :, kk) = (model.sim_lfg_SrcActiv_orig.LFG * model.sim_sig_SrcActiv.sigSRC_pst(:, :, kk)')';
        model.sim_sig_IntNoise.sigSNS_pre(:, :, kk) = (model.sim_lfg_IntNoise_orig.LFG * model.sim_sig_IntNoise.sigSRC_pre(:, :, kk)')';
        model.sim_sig_IntNoise.sigSNS_pst(:, :, kk) = (model.sim_lfg_IntNoise_orig.LFG * model.sim_sig_IntNoise.sigSRC_pst(:, :, kk)')';
        model.sim_sig_BcgNoise.sigSNS_pre(:, :, kk) = (model.sim_lfg_BcgNoise_orig.LFG * model.sim_sig_BcgNoise.sigSRC_pre(:, :, kk)')';
        model.sim_sig_BcgNoise.sigSNS_pst(:, :, kk) = (model.sim_lfg_BcgNoise_orig.LFG * model.sim_sig_BcgNoise.sigSRC_pst(:, :, kk)')';
    end
end