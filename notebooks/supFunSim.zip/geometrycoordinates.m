function model = geometrycoordinates(SETUP, MODEL, MATS)
   % Finds coordinates corresponding to drawn ROIs.

    model = MODEL;
    model.sim_geo_cort.distrROIs = SETUP.SRCS;
    model.sim_geo_cort.distrROIsSum = sum(SETUP.SRCS, 2);
    model.sim_geo_cort.bulkSRC = {};
    if SETUP.SEED
        rng(SETUP.SEEDS(5));
    end
    for ii = 1:length(model.sim_geo_cort.distrROIsSum)
        model.sim_geo_cort.bulkSRC{ii, 1} = randsample(model.sim_geo_cort.indROIs(ii).pntNum00, model.sim_geo_cort.distrROIsSum(ii));
    end
    model.sim_geo_cort.splitSRC = {};
    for ii = 1:length(model.sim_geo_cort.distrROIsSum)
        model.sim_geo_cort.splitSRC(ii, :) = mat2cell(model.sim_geo_cort.bulkSRC{ii}, model.sim_geo_cort.distrROIs(ii, :), 1)';
    end

    if SETUP.DEBUG
       model.sim_geo_cort.splitSRC(1, 1)
       model.sim_geo_cort.splitSRC{1, 1}
    end

    if SETUP.rPNT
        disp('CC: using random source locations')
    else
        disp('CC: using predefined source locations')
        %model.sim_geo_cort.splitSRC{1, 1} = [5441; 5506; 5481; 5283; 5144; 5063; 5823; 5987; 6154; 6065; 6166; 6346; 6087; 6446; 6367; 6726; 6859; 6829; 6613; 6698; 6966; 7162; 7227; 6949; 6996; 7365; 7247; 7480];
        model.sim_geo_cort.splitSRC{1, 1} = model.sim_geo_cort.splitSRC{1, 1}(1:SETUP.SRCS(1, 1));
        if SETUP.DEBUG
           model.sim_geo_cort.splitSRC{1, 1}
        end
    end

    model.sim_geo_cort.mergeSRC = {};
    for ii = 1:3
        model.sim_geo_cort.mergeSRC{ii} = cat(1, model.sim_geo_cort.splitSRC{:, ii});
    end
    model.sim_geo_cort.pos_orig = {};
    model.sim_geo_cort.ori_orig = {};
    model.sim_geo_cort.pos_pert = {};
    model.sim_geo_cort.ori_pert = {};
    for ii = 1:3
        model.sim_geo_cort.pos_orig{ii} = MATS.sel_atl.pnt(model.sim_geo_cort.mergeSRC{ii}, :);
        model.sim_geo_cort.ori_orig{ii} = MATS.sel_atl.vn1(model.sim_geo_cort.mergeSRC{ii}, :);
        model.sim_geo_cort.pos_pert{ii} = model.sim_geo_cort.pos_orig{ii};
        model.sim_geo_cort.ori_pert{ii} = model.sim_geo_cort.ori_orig{ii};
    end
end