function PDCgraph(SETUP, MODEL)

    figure(100);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    rawPlotA00(MODEL.sim_sig_SrcActiv.A00);
    set(gcf, 'color', 'w');
    figure(101);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    rawPlotA00(MODEL.sim_sig_SrcActiv.A01);
    set(gcf, 'color', 'w');

    figure(130);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    rawPlotA00(MODEL.sim_sig_IntNoise.A00);
    set(gcf, 'color', 'w');
    figure(131);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    rawPlotA00(MODEL.sim_sig_IntNoise.A01);
    set(gcf, 'color', 'w');

    figure(140);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    rawPlotA00(MODEL.sim_sig_BcgNoise.A00);
    set(gcf, 'color', 'w');
    figure(131);
    clf;
    set(gcf, 'Position', SETUP.DISP);
    rawPlotA00(MODEL.sim_sig_BcgNoise.A01);
    set(gcf, 'color', 'w');
end