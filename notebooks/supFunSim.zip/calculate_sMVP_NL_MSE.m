function model = calculate_sMVP_NL_MSE(MODEL)
    % Definition of sMVP_NL_MSE filter.

    model = MODEL;
    
    model.K_NL_MSE = pinv(model.P_sMVP_NL_R * model.H_Src_R) * model.P_sMVP_NL_R * (pinv(model.P_sMVP_NL_R * model.H_Src_R))' - 2*model.C_NL;
    [model.U_K_NL_MSE, model.W_K_NL_MSE] = eig(model.K_NL_MSE);
    [~, model.p_K_NL_MSE] = sort(diag(model.W_K_NL_MSE));
    % note: for selecting optimal rank, Theobald's Theorem can be
    % used without evaluation of the cost function, or it can be
    % done as here:
    model.U_K_NL_MSE = model.U_K_NL_MSE(:, model.p_K_NL_MSE);
    model.sMVP_NL_MSE_ranks = zeros(1, size(model.H_Src, 2));

    for jj = 1:size(model.H_Src, 2)
        % cost function
        model.sMVP_NL_MSE_ranks(jj) = trace(model.U_K_NL_MSE(:, 1:jj) * model.U_K_NL_MSE(:, 1:jj)' * model.K_NL_MSE);
    end

    [~, model.sMVP_NL_MSE_rank_opt] = min(model.sMVP_NL_MSE_ranks);
    % _opt stands for optimal
    model.P_sMVP_NL_MSE_opt = model.U_K_NL_MSE(:, 1:model.sMVP_NL_MSE_rank_opt) * model.U_K_NL_MSE(:, 1:model.sMVP_NL_MSE_rank_opt)';

    model.rec_opt.ranks.sMVP_NL_MSE = model.sMVP_NL_MSE_rank_opt;

    model.rec_flt.sMVP_NL_MSE = model.P_sMVP_NL_MSE_opt * pinv(model.P_sMVP_NL_R * model.H_Src_R) * model.P_sMVP_NL_R * pinv(sqrtm(model.R));
end